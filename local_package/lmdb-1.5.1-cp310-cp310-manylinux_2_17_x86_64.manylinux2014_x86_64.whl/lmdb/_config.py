CONFIG = dict((('extra_compile_args', ['-DHAVE_PATCHED_LMDB=1', '-UNDEBUG', '-w']), ('extra_sources', ['build/lib/mdb.c', 'build/lib/midl.c']), ('extra_library_dirs', []), ('extra_include_dirs', ['lib/py-lmdb', 'build/lib']), ('libraries', [])))

